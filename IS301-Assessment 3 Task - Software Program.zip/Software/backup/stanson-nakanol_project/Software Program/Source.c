/*	IS301 Structured Programming Assessment Task 3 (A3) 
	Major Assignment 
	Weight: 20%
	Due: Friday Week 15 at 11pm
	Lesson outcomes assessed: 1, 2,3,4,5 and 6
	Programmer: Stanson NAKANOL
*/

#pragma warning(disable: 4996) //CRT_SECURE_NO_WARNINGS
/*To turn off the warning within a file for everything that follows.*/
#include<stdio.h> //header file
/* C programming standard library functions for file input and output*/

/******************************************* Global variables **********************************************/

// defining appropriate symbolic contants as necessary
#define MaxVotes 17 // stores the maximum number of votes
#define MaxNameLength 50 // stores the size of the string characters

//file pointer to open connection for text files
FILE *in, *out;

/******************************************* main function ************************************************/
int main() {

	//open and read sdGoals.txt file
	in = fopen("sdGoals.txt", "r");

	//open and write to sdgSelection.txt file
	out = fopen("sdgSelection.txt", "w");

	//Declaring approprite 2D arrays to store the sdGoals
	char sdGoal[MaxVotes + 1][MaxNameLength + 1]; // stores the sdGoals that are read from the file. 
	int numVote[MaxVotes + 1]; // stores the number of votes that are read from the file	

	//Declaring the function prototypes 
	void selectionInitializer(char[][MaxNameLength + 1], int[]); // selectionInitializer function prototype 
	void printResult(char[][MaxNameLength + 1], int[], int, int); // printResult function prototype

	//Declaring variables to count and store votes 
	int vote = 0, validVote = 0, invalidVote = 0;

	selectionInitializer(sdGoal, numVote);
	fscanf(in, "%d", &vote); // scan number of votes in the sdGoal text file and store them in vote variable

	// Determining the validity of the votes
	while (vote != 0) //end of file marker 
	{
		if (vote < 1 || vote > MaxVotes) {
			fprintf(out, "Invalid votes: %d\n", vote); // prints the number of invalid votes
			++invalidVote; // stores the number of invalid votes
		}
		else {
			++numVote[vote]; // counts the number of valid votes
			++validVote; // stores the number of valid votes
		}
		fscanf(in, "%d", &vote); // scan number of votes in the sdGoal text file and store them in vote variable
	}

	// printResult function prototype 
	printResult(sdGoal, numVote, validVote, invalidVote);
	/*
		The printResult function is called here to perform to calculate and print the number of
		valid and invalid votes, total number of votes and votes, and sdGoals with their respective
		votes that were made
	*/

	//close connections to the text files
	fclose(in);
	fclose(out);
	system("pause");
}// end of main function 


 /*********************************** selectionInitializer function ********************************************/
/*
  The selectionInitializer has the job of intializing the program and concatenate the first and
  last name of the goals that will be printed in the sdgSelection text file.
*/
void selectionInitializer(char Name[][MaxNameLength + 1], int vote[]) { // function header
	char lastName[MaxNameLength]; // 1D array that stores the last name (second character of string) after whitespace
	for (int c = 1; c <= MaxVotes; c++) {
		fscanf(in, "%s %s", Name[c], lastName); // reads two string, that is; name array and lastname
		strcat(Name[c], " ");  // concatenates (joins) name array and white space
		strcat(Name[c], lastName); // concatenates (joins) name array, whitespace and lastName array
		vote[c] = 0; // intializes the vote array to zero. 
	}
} // end of selectionInitizer function

/********************************** getHighestVote function ***************************************************/
int getHighestVote(int num[], int lowVote, int highVote) { // function header 
	/*
		The getHighestVote function has the job of proccessing votes for each of the goals
		listed in the sdGoals text file. Then, it will determine the goal(s) that has the
		highest frequency of votes.
	*/
	int big = lowVote; // declaring big variable and initialize with lowVote values
	for (int v = lowVote + 1; v <= highVote; v++)  // loop to compare the votes stored in the array
		if (num[v] > num[big]) big = v;
	/* if the number v stored in the num[] array is greater than the number big stored 
	in the num[] array, then big = h */

	return big; // return the highest vote 	
} // end getHighestVote function 

/*************************************** printResult function **************************************************/
void printResult(char sdGoals[][MaxNameLength + 1], int vote[], int validVote, int invalidVote) {
	/*
		printResult function has the job of printing the total number of voters, the number over 
		valid votes, the number of invalid votes. Also, it is responsible for printing the name of sdGoals 
		and their votes respectively.
	*/
	int getHighestVote(int v[], int, int); // declaring getHighestVote function prototype

	fprintf(out, "\nNumber of voters: %d\n", validVote + invalidVote); // prints the total number of voters
	fprintf(out, "\nNumber of valid votes: %d\n", validVote); // prints the number of invalid votes
	fprintf(out, "\nNumber of invalid votes: %d\n", invalidVote); // prints the number invalid votes
	fprintf(out, "\nScores (votes) per Goal\n\n"); // title header for the votes per Goal

	for (int c = 1; c <= MaxVotes; c++) // loops through the votes of each sdGoals in the text file
		fprintf(out, "\t %-15s %3d\n", sdGoals[c], vote[c]); 
		// print the name of the goal and their number of votes made

	fprintf(out, "\nTop Selection(s):\n"); // title header for the top selections

	int winner = getHighestVote(vote, 1, MaxVotes);
	// variable winner is declared to hold the getHighestVote function call
	// getHighestVote function will start the count from the position of 1st index up to the 17th index of the array

	int winningVote = vote[winner]; // variable winningVote is declared to hold the winner variable

	for (int i = 1; i <= MaxVotes; i++)  //This for loop is created to count from 1 up to 17.
		if (vote[i] == winningVote) fprintf(out, "\t %s\n", sdGoals[i]);
	/*
		if the value in vote[i] array is equal to the winningVote value, then print the sdGoal(s)
		with the highest vote under the top selection(s).
	*/
} // end of printResult function 